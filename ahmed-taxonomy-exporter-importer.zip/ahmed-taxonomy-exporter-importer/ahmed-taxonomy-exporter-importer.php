<?php
/**
 * Plugin Name: Custom Product Taxonomy Exporter & Importer
 * Plugin URI:  https://github.com/ahmedeid
 * Description: Add custom WooCommerce product taxonomies to the CSV exporter and importer.
 * Version:     2.0.0
 * Author:      Ahmed Eid
 * Author URI:  https://github.com/ahmedeid
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ahmed-taxonomy-ei
 * WC requires at least: 4.2
 * WC tested up to: 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ATEI_VERSION',     '2.0.0' );
define( 'ATEI_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'ATEI_TEXT_DOMAIN', 'ahmed-taxonomy-ei' );

require_once ATEI_PLUGIN_DIR . 'inc/class-get-product-taxonomy.php';
require_once ATEI_PLUGIN_DIR . 'inc/class-export-taxonomy.php';
require_once ATEI_PLUGIN_DIR . 'inc/class-import-taxonomy.php';

use ATEI\GetProductTaxonomy;
use ATEI\ExportTaxonomy;
use ATEI\ImportTaxonomy;

class ATEI_Init {

    /** @var array */
    private $custom_taxonomies = [];

    /** @var GetProductTaxonomy */
    private $taxonomy_handler;

    /**
     * @param GetProductTaxonomy $taxonomy_handler
     */
    public function __construct( GetProductTaxonomy $taxonomy_handler ) {

        if ( ! $this->is_woocommerce_active() ) {
            add_action( 'admin_notices', [ $this, 'show_woocommerce_notice' ] );
            return;
        }

        $this->taxonomy_handler = $taxonomy_handler;

        add_action( 'init', [ $this, 'load_export_import' ] );
        add_filter( 'woocommerce_get_sections_products', [ $this, 'add_settings_tab' ] );
        add_filter( 'woocommerce_get_settings_products', [ $this, 'get_settings' ], 10, 2 );
    }

    public function load_export_import() {

        if ( ! is_admin() ) {
            return;
        }

        $this->custom_taxonomies = $this->taxonomy_handler->get_custom_taxonomies();
        $this->register_taxonomy_columns();
    }

    /**
     * @param array $sections
     * @return array
     */
    public function add_settings_tab( $sections ) {
        $sections['atei_taxonomies'] = __( 'Custom Taxonomies (Export/Import)', ATEI_TEXT_DOMAIN );
        return $sections;
    }

    /**
     * @param array  $settings
     * @param string $current_section
     * @return array
     */
    public function get_settings( $settings, $current_section ) {

        if ( 'atei_taxonomies' !== $current_section ) {
            return $settings;
        }

        $fields = [];

        $fields[] = [
            'name' => __( 'Custom Product Taxonomies', ATEI_TEXT_DOMAIN ),
            'type' => 'title',
            'desc' => __( 'Select which custom taxonomies to include in the CSV export/import.', ATEI_TEXT_DOMAIN ),
            'id'   => 'atei_section_start',
        ];

        if ( ! empty( $this->custom_taxonomies ) ) {
            foreach ( $this->custom_taxonomies as $taxonomy ) {
                $fields[] = [
                    'name' => esc_html( $taxonomy->labels->singular_name ),
                    'type' => 'checkbox',
                    'desc' => sprintf(
                        /* translators: %s: taxonomy name */
                        __( 'Include "%s" in CSV', ATEI_TEXT_DOMAIN ),
                        esc_html( $taxonomy->labels->singular_name )
                    ),
                    'id'   => 'atei_csv_' . sanitize_key( $taxonomy->name ),
                ];
            }
        } else {
            $fields[] = [
                'type' => 'title',
                'desc' => __( 'No custom product taxonomies found.', ATEI_TEXT_DOMAIN ),
                'id'   => 'atei_no_tax',
            ];
        }

        $fields[] = [ 'type' => 'sectionend', 'id' => 'atei_section_start' ];

        return $fields;
    }

    private function register_taxonomy_columns() {

        if ( empty( $this->custom_taxonomies ) ) {
            return;
        }

        foreach ( $this->custom_taxonomies as $taxonomy ) {
            $tax_id   = $taxonomy->name;
            $tax_name = $taxonomy->labels->singular_name;
            $enabled  = WC_Admin_Settings::get_option( 'atei_csv_' . sanitize_key( $tax_id ) );

            if ( 'yes' === $enabled ) {
                new ExportTaxonomy( $tax_id, $tax_name );
                new ImportTaxonomy( $tax_id, $tax_name );
            }
        }
    }

    public function show_woocommerce_notice() {
        $message = sprintf(
            /* translators: 1: opening anchor tag, 2: closing anchor tag */
            __( '<strong>Custom Taxonomy Exporter/Importer</strong> requires %1$sWooCommerce%2$s to be installed and activated.', ATEI_TEXT_DOMAIN ),
            '<a href="https://wordpress.org/plugins/woocommerce/" target="_blank">',
            '</a>'
        );
        printf( '<div class="notice notice-error"><p>%s</p></div>', wp_kses_post( $message ) );
    }

    /**
     * @return bool
     */
    private function is_woocommerce_active() {
        $active_plugins      = (array) get_option( 'active_plugins', [] );
        $active_site_plugins = is_multisite()
            ? array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) )
            : [];

        return in_array( 'woocommerce/woocommerce.php', $active_plugins, true )
            || in_array( 'woocommerce/woocommerce.php', $active_site_plugins, true );
    }
}

$atei_taxonomy_handler = new GetProductTaxonomy();
new ATEI_Init( $atei_taxonomy_handler );

<?php
namespace ATEI;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ImportTaxonomy {

    /** @var string */
    private $taxonomy_id;

    /** @var string */
    private $taxonomy_name;

    /**
     * @param string $taxonomy_id
     * @param string $taxonomy_name
     */
    public function __construct( $taxonomy_id, $taxonomy_name ) {
        $this->taxonomy_id   = sanitize_key( $taxonomy_id );
        $this->taxonomy_name = sanitize_text_field( $taxonomy_name );

        add_filter( 'woocommerce_csv_product_import_mapping_options',         [ $this, 'map_columns' ] );
        add_filter( 'woocommerce_csv_product_import_mapping_default_columns', [ $this, 'add_auto_mapping' ] );
        add_filter( 'woocommerce_product_importer_parsed_data',               [ $this, 'parse_taxonomy_field' ], 10, 2 );
        add_filter( 'woocommerce_product_import_inserted_product_object',     [ $this, 'set_taxonomy_terms' ], 10, 2 );
    }

    /**
     * @param array $columns
     * @return array
     */
    public function map_columns( $columns ) {
        $columns[ $this->taxonomy_id ] = $this->taxonomy_name;
        return $columns;
    }

    /**
     * @param array $columns
     * @return array
     */
    public function add_auto_mapping( $columns ) {
        $columns[ $this->taxonomy_name ] = $this->taxonomy_id;
        return $columns;
    }

    /**
     * Parse comma-separated taxonomy names into term IDs.
     * Creates the term automatically if it does not exist.
     *
     * @param array                   $parsed_data
     * @param WC_Product_CSV_Importer $importer
     * @return array
     */
    public function parse_taxonomy_field( $parsed_data, $importer ) {

        if ( empty( $parsed_data[ $this->taxonomy_id ] ) ) {
            return $parsed_data;
        }

        $raw_names = array_map( 'trim', explode( ',', $parsed_data[ $this->taxonomy_id ] ) );
        unset( $parsed_data[ $this->taxonomy_id ] );

        $term_ids = [];

        foreach ( $raw_names as $term_name ) {
            if ( empty( $term_name ) ) {
                continue;
            }

            // Try to find the term first
            $term = get_term_by( 'name', $term_name, $this->taxonomy_id );

            // If not found, create it automatically
            if ( ! $term || is_wp_error( $term ) ) {
                $new_term = wp_insert_term( $term_name, $this->taxonomy_id );
                if ( ! is_wp_error( $new_term ) ) {
                    $term_ids[] = (int) $new_term['term_id'];
                }
            } else {
                $term_ids[] = (int) $term->term_id;
            }
        }

        if ( ! empty( $term_ids ) ) {
            $parsed_data[ $this->taxonomy_id ] = $term_ids;
        }

        return $parsed_data;
    }

    /**
     * Assign taxonomy terms to the product after import.
     *
     * @param WC_Product $product
     * @param array      $data
     * @return WC_Product
     */
    public function set_taxonomy_terms( $product, $data ) {

        if ( ! ( $product instanceof \WC_Product ) ) {
            return $product;
        }

        if ( ! empty( $data[ $this->taxonomy_id ] ) ) {
            $result = wp_set_object_terms(
                $product->get_id(),
                (array) $data[ $this->taxonomy_id ],
                $this->taxonomy_id
            );
        }

        return $product;
    }
}

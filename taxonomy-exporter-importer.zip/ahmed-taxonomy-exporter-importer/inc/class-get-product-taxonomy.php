<?php
namespace ATEI;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class GetProductTaxonomy {

    /**
     * Get custom product taxonomies excluding WooCommerce defaults and attributes.
     *
     * @return array
     */
    public function get_custom_taxonomies() {
        $all_taxonomies = $this->get_product_taxonomies();

        $excluded = [ 'product_type', 'product_cat', 'product_tag' ];

        foreach ( array_keys( $all_taxonomies ) as $key ) {
            if ( strpos( $key, 'pa_' ) === 0 ) {
                $excluded[] = $key;
            }
        }

        return array_diff_key( $all_taxonomies, array_flip( $excluded ) );
    }

    /**
     * Get all taxonomies registered for the product post type.
     *
     * @return array
     */
    private function get_product_taxonomies() {
        return get_taxonomies(
            [ 'object_type' => [ 'product' ] ],
            'objects'
        );
    }
}

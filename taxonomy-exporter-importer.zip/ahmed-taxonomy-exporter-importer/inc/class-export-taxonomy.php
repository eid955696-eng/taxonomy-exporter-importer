<?php
namespace ATEI;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ExportTaxonomy {

    /** @var string */
    private $taxonomy_id;

    /** @var string */
    private $taxonomy_name;

    /**
     * @param string $taxonomy_id
     * @param string $taxonomy_name
     */
    public function __construct( $taxonomy_id, $taxonomy_name ) {
        $this->taxonomy_id   = sanitize_key( $taxonomy_id );
        $this->taxonomy_name = sanitize_text_field( $taxonomy_name );

        add_filter( 'woocommerce_product_export_column_names',            [ $this, 'add_column' ] );
        add_filter( 'woocommerce_product_export_product_default_columns', [ $this, 'add_column' ] );
        add_filter(
            'woocommerce_product_export_product_column_' . $this->taxonomy_id,
            [ $this, 'export_taxonomy_data' ],
            10,
            2
        );
    }

    /**
     * Add column header to the CSV export.
     *
     * @param array $columns
     * @return array
     */
    public function add_column( $columns ) {
        $columns[ $this->taxonomy_id ] = $this->taxonomy_name;
        return $columns;
    }

    /**
     * Export taxonomy terms for a product as a comma-separated string.
     *
     * @param mixed      $value
     * @param WC_Product $product
     * @return string
     */
    public function export_taxonomy_data( $value, $product ) {
        $terms = get_the_terms( $product->get_id(), $this->taxonomy_id );

        if ( is_wp_error( $terms ) || empty( $terms ) ) {
            return '';
        }

        return implode( ', ', wp_list_pluck( $terms, 'name' ) );
    }
}

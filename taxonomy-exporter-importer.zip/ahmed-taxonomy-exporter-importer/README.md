# Custom Product Taxonomy Exporter & Importer

A WordPress plugin that adds support for custom product taxonomies in WooCommerce CSV export and import.

## Requirements

- WordPress 5.0+
- WooCommerce 4.2+
- PHP 7.4+

## Installation

1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate the plugin from the **Plugins** menu
3. Go to **WooCommerce → Settings → Products → Custom Taxonomies**
4. Check the taxonomies you want to include in CSV export/import
5. Save settings

## Usage

Once activated and configured, any checked taxonomy will automatically appear as a column in WooCommerce product CSV exports and be recognized during imports.

## File Structure

```
ahmed-taxonomy-exporter-importer/
├── ahmed-taxonomy-exporter-importer.php
├── inc/
│   ├── class-get-product-taxonomy.php
│   ├── class-export-taxonomy.php
│   └── class-import-taxonomy.php
└── README.md
```

## License

GPLv2 or later — https://www.gnu.org/licenses/gpl-2.0.html
